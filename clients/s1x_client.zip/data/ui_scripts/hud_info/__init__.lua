if (game:issingleplayer()) then
	return
end

require("settings")
require("hud")
if (game:issingleplayer() or not Engine.InFrontend()) then
    return
end

require("lobby")
require("serverlist")

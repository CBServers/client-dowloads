How to use:
Extract this zip file
Go to you AW/S1x install folder
Navigate to players2 -> user folder
Put the two files from this folder (mpdata and mpdata2) into that folder
Replace any conflicts